
INSERT INTO `db_a_bank_num` VALUES (null,	'785584000009',	'华商银行',	'华商银行',	'785');
INSERT INTO `db_a_bank_num` VALUES (null,	'785581000003',	'华商银行广州分行',	'华商银行',	'785');
INSERT INTO `db_a_bank_num` VALUES (null,	'785584000017',	'华商银行深圳分行',	'华商银行',	'785');
INSERT INTO `db_a_bank_num` VALUES (null,	'785584000025',	'华商银行总行营业部',	'华商银行',	'785');
INSERT INTO `db_a_bank_num` VALUES (null,	'785584000033',	'华商银行深圳科技园支行',	'华商银行',	'785');
