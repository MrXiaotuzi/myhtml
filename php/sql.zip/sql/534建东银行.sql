
INSERT INTO `db_a_bank_num` VALUES (null,	'534393000015',	'美国建东银行有限公司厦门分行',	'美国建东银行',	'534');
