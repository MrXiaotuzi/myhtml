
INSERT INTO `db_a_bank_num` VALUES (null,	'531222000010',	'花旗银行大连分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531290088881',	'花旗银行(中国)有限公司',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531110000011',	'花旗银行（中国）有限公司天津分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531100000018',	'花旗银行（中国）有限公司北京分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531290000011',	'花旗银行（中国）有限公司上海分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531584000009',	'花旗银行（中国）有限公司深圳分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531581000011',	'花旗银行（中国）有限公司广州分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531651000018',	'花旗银行成都分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531331000015',	'花旗银行（中国）有限公司杭州分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531653000011',	'花旗银行（中国）有限公司重庆分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531701000013',	'花旗银行（中国）有限公司贵阳分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531551000009',	'花旗银行（中国）有限公司长沙分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531301000014',	'花旗银行（中国）有限公司南京分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531302000016',	'花旗银行（中国）有限公司无锡分行',	'花旗银行',	'531');
INSERT INTO `db_a_bank_num` VALUES (null,	'531290000134',	'花旗银行（中国）有限公司上海自贸试验区支行',	'花旗银行',	'531');
