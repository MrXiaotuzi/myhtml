
INSERT INTO `db_a_bank_num` VALUES (null,	'506393001041',	'集友银行有限公司厦门观音山支行',	'集友银行',	'506');
INSERT INTO `db_a_bank_num` VALUES (null,	'506391000019',	'集友银行有限公司福州分行',	'集友银行',	'506');
INSERT INTO `db_a_bank_num` VALUES (null,	'506393001025',	'集友银行有限公司厦门分行',	'集友银行',	'506');
INSERT INTO `db_a_bank_num` VALUES (null,	'506393001033',	'集友银行有限公司厦门集美支行',	'集友银行',	'506');
