
INSERT INTO `db_a_bank_num` VALUES (null,	'565452000012',	'日本山口银行股份有限公司青岛分行',	'日本山口银行',	'565');
