
INSERT INTO `db_a_bank_num` VALUES (null,	'323290000016',	'上海华瑞银行',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323584000888',	'深圳前海微众银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323301000019',	'江苏苏宁银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323110000008',	'天津金城银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323596001013',	'梅州客商银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323241000016',	'吉林亿联银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323221000086',	'辽宁振兴银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323391060018',	'福建华通银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323333000013',	'温州民商银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323331000001',	'浙江网商银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323551000015',	'湖南三湘银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323653010015',	'重庆富民银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323100000012',	'北京中关村银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323651066666',	'四川新网银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323521012066',	'武汉众邦银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323465000019',	'威海蓝海银行股份有限公司',	'民营银行',	'323');
INSERT INTO `db_a_bank_num` VALUES (null,	'323361000014',	'安徽新安银行股份有限公司',	'民营银行',	'323');
