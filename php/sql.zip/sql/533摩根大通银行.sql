
INSERT INTO `db_a_bank_num` VALUES (null,	'533100000017',	'摩根大通银行（中国）有限公司北京分行',	'摩根大通银行（中国）',	'533');
INSERT INTO `db_a_bank_num` VALUES (null,	'533261000011',	'摩根大通银行（中国）有限公司哈尔滨分行',	'摩根大通银行（中国）',	'533');
INSERT INTO `db_a_bank_num` VALUES (null,	'533100000009',	'摩根大通银行(中国)有限公司',	'摩根大通银行（中国）',	'533');
INSERT INTO `db_a_bank_num` VALUES (null,	'533290000019',	'摩根大通银行（中国）有限公司上海分行',	'摩根大通银行（中国）',	'533');
INSERT INTO `db_a_bank_num` VALUES (null,	'533581000018',	'摩根大通银行（中国）有限公司广州分行',	'摩根大通银行（中国）',	'533');
INSERT INTO `db_a_bank_num` VALUES (null,	'533110000019',	'摩根大通银行（中国）有限公司天津分行',	'摩根大通银行（中国）',	'533');
INSERT INTO `db_a_bank_num` VALUES (null,	'533651000014',	'摩根大通银行（中国）有限公司成都分行',	'摩根大通银行（中国）',	'533');
INSERT INTO `db_a_bank_num` VALUES (null,	'533584000013',	'摩根大通银行（中国）有限公司深圳分行',	'摩根大通银行（中国）',	'533');
INSERT INTO `db_a_bank_num` VALUES (null,	'533305000012',	'摩根大通银行（中国）有限公司苏州分行',	'摩根大通银行（中国）',	'533');
