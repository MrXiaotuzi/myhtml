
INSERT INTO `db_a_bank_num` VALUES (null,	'563305000015',	'三井住友银行(中国)有限公司苏州分行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563331000019',	'三井住友银行（中国）有限公司杭州分行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563110000018',	'三井住友银行(中国)有限公司天津分行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563290000018',	'三井住友银行(中国)有限公司',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563581000015',	'三井住友银行（中国）有限公司广州分行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563100000014',	'三井住友银行(中国)有限公司北京分行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563584000012',	'三井住友银行(中国)有限公司深圳分行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563221000014',	'三井住友银行(中国)有限公司沈阳分行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563290000026',	'三井住友银行(中国)有限公司上海自贸试验区支行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563653000015',	'三井住友银行(中国)有限公司重庆分行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563305200017',	'三井住友银行(中国)有限公司昆山支行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563305500019',	'三井住友银行(中国)有限公司常熟支行',	'三井住友银行',	'563');
INSERT INTO `db_a_bank_num` VALUES (null,	'563222000016',	'三井住友银行（中国）有限公司大连分行',	'三井住友银行',	'563');
