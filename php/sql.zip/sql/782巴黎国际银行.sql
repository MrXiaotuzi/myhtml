
INSERT INTO `db_a_bank_num` VALUES (null,	'782290000018',	'法国巴黎银行（中国）有限公司',	'巴黎国际银行',	'782');
INSERT INTO `db_a_bank_num` VALUES (null,	'782100000014',	'法国巴黎银行（中国）有限公司北京分行',	'巴黎国际银行',	'782');
INSERT INTO `db_a_bank_num` VALUES (null,	'782581000015',	'法国巴黎银行(中国)有限公司广州分行',	'巴黎国际银行',	'782');
INSERT INTO `db_a_bank_num` VALUES (null,	'782110000018',	'法国巴黎银行（中国）有限公司天津分行',	'巴黎国际银行',	'782');
INSERT INTO `db_a_bank_num` VALUES (null,	'782290000026',	'法国巴黎银行（中国）有限公司上海自贸试验区支行',	'巴黎国际银行',	'782');
