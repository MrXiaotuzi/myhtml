
INSERT INTO `db_a_bank_num` VALUES (null,	'561302000013',	'三菱东京日联银行（中国）有限公司无锡分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561305000019',	'三菱东京日联银行（中国）有限公司苏州分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561100000015',	'三菱东京日联银行(中国)有限公司北京分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561110000012',	'三菱东京日联银行（中国）有限公司天津分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561222000013',	'三菱东京日联银行(中国)有限公司大连分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561290000015',	'三菱日联银行（中国）有限公司上海分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561584099995',	'三菱东京日联银行(中国）有限公司深圳分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561581000019',	'三菱东京日联银行(中国)有限公司广州分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561651000015',	'三菱东京日联银行(中国)有限公司成都分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561521000013',	'三菱东京日联银行（中国）有限公司武汉分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561452036739',	'三菱东京日联银行(中国)有限公司青岛分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561221000011',	'三菱东京日联银行（中国）有限公司沈阳分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561391000018',	'三菱东京日联银行（中国）有限公司福州分行',	'株式会社东京三菱银行',	'561');
INSERT INTO `db_a_bank_num` VALUES (null,	'561331000012',	'三菱东京日联银行（中国）有限公司杭州分行',	'株式会社东京三菱银行',	'561');
