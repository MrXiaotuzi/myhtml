
INSERT INTO `db_a_bank_num` VALUES (null,	'532100000012',	'美国银行有限公司北京分行',	'美国美洲银行',	'532');
INSERT INTO `db_a_bank_num` VALUES (null,	'532581000016',	'美国银行有限公司广州分行',	'美国美洲银行',	'532');
INSERT INTO `db_a_bank_num` VALUES (null,	'532290010011',	'美国银行有限公司上海分行',	'美国美洲银行',	'532');
