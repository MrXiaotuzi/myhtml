
INSERT INTO `db_a_bank_num` VALUES (null,	'564100000016',	'瑞穗银行（中国）有限公司北京分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564110000010',	'瑞穗银行（中国）有限公司天津分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564222000014',	'瑞穗银行（中国）有限公司大连分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564290000010',	'瑞穗银行（中国）有限公司',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564584000007',	'瑞穗银行（中国）有限公司深圳分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564521000018',	'瑞穗银行（中国）有限公司武汉分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564452000013',	'瑞穗银行（中国）有限公司青岛分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564581000010',	'瑞穗银行（中国）有限公司广州分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564302000014',	'瑞穗银行（中国）有限公司无锡分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564305000028',	'瑞穗银行（中国）有限公司苏州分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564361000018',	'瑞穗银行（中国）有限公司合肥分行',	'瑞穗实业银行',	'564');
INSERT INTO `db_a_bank_num` VALUES (null,	'564290000028',	'瑞穗银行（中国）有限公司上海自贸试验区支行',	'瑞穗实业银行',	'564');
