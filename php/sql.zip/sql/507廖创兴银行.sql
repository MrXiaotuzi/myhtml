
INSERT INTO `db_a_bank_num` VALUES (null,	'507586000014',	'创兴银行有限公司汕头分行',	'创兴银行',	'507');
INSERT INTO `db_a_bank_num` VALUES (null,	'507585000061',	'创兴银行有限公司广东自贸试验区横琴支行',	'创兴银行',	'507');
INSERT INTO `db_a_bank_num` VALUES (null,	'507581000021',	'创兴银行有限公司广州天河支行',	'创兴银行',	'507');
INSERT INTO `db_a_bank_num` VALUES (null,	'507581000013',	'创兴银行有限公司广州分行',	'创兴银行',	'507');
INSERT INTO `db_a_bank_num` VALUES (null,	'507581000048',	'创兴银行有限公司广东自贸试验区南沙支行',	'创兴银行',	'507');
INSERT INTO `db_a_bank_num` VALUES (null,	'507584000019',	'创兴银行有限公司深圳分行',	'创兴银行',	'507');
INSERT INTO `db_a_bank_num` VALUES (null,	'507588000034',	'创兴银行有限公司佛山支行',	'创兴银行',	'507');
