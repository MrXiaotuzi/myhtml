
INSERT INTO `db_a_bank_num` VALUES (null,	'717653000016',	'中德住房储蓄银行有限责任公司重庆分行',	'中德住房储蓄银行',	'717');
INSERT INTO `db_a_bank_num` VALUES (null,	'717110000108',	'中德住房储蓄银行有限责任公司天津和平支行',	'中德住房储蓄银行',	'717');
INSERT INTO `db_a_bank_num` VALUES (null,	'717110000010',	'中德住房储蓄银行',	'中德住房储蓄银行',	'717');
INSERT INTO `db_a_bank_num` VALUES (null,	'717110000116',	'中德住房储蓄银行有限责任公司天津滨海支行',	'中德住房储蓄银行',	'717');
