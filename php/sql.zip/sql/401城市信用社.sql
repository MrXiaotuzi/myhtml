
INSERT INTO `db_a_bank_num` VALUES (null,	'401224200814',	'新宾满族自治县苏水城市信用合作社',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228000348',	'营口经济技术开发区熊岳城市信用合作社',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228000356',	'营口经济技术开发区熊岳城市信用合作社兴利储蓄所',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228000364',	'营口经济技术开发区熊岳城市信用合作社财源储蓄所',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228200161',	'盖州市城市建设信用合作社',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228200170',	'盖州市城市建设信用合作社辰北储蓄所',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228200188',	'盖州市辰州城市信用合作社',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228200196',	'盖州市辰州城市信用合作社辰兴储蓄所',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228200207',	'盖州市城市信用合作社',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401228200215',	'盖州市城市信用合作社中海储蓄所',	'城市信用合作社',	'401');
INSERT INTO `db_a_bank_num` VALUES (null,	'401234400934',	'清原满族自治县中心城市信用合作社',	'城市信用合作社',	'401');
