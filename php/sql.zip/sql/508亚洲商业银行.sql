
INSERT INTO `db_a_bank_num` VALUES (null,	'508584000017',	'大众银行（香港）有限公司深圳分行',	'大众银行（香港）有限公司',	'508');
